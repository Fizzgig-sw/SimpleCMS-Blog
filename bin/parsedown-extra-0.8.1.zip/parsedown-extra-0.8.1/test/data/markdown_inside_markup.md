<div class="example" markdown="1">
_markdown_

This is another paragraph. It contains <em>inline markup</em>.
<div>
_no markdown_
</div>
</div>

---

<div markdown="1">
_markdown_
<div markdown="1">
_markdown_
</div>
</div>

---

<div>
_no markdown_
<div markdown="1">
_markdown_
</div>
</div>

---

<div markdown="0">
_no markdown_
</div>