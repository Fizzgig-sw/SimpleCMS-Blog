<?php

class TestParsedown extends ParsedownExtra
{
    public function getTextLevelElements()
    {
        return $this->textLevelElements;
    }
}
